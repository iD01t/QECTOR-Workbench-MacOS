"""cli.py: command line interface for QECTOR Decoder Workbench.

Supports interactive and automated terminal workflows across Windows, Linux and
macOS. Wires the backend features: 16 decoders, 10 code families,
self-diagnostics, hardware routing, benchmarks, document generation and MCP
server launch.
"""
from __future__ import annotations

import argparse
import json
import re
import os
import sys
from typing import Any, Optional

# Enable VT100 colors on Windows
if sys.platform == "win32":
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        os.system("")

# ANSI Color Tokens
class C:
    CYAN = "\033[96m"
    MAGENTA = "\033[95m"
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    @classmethod
    def disable(cls):
        cls.CYAN = cls.MAGENTA = cls.BLUE = cls.GREEN = cls.YELLOW = cls.RED = cls.BOLD = cls.DIM = cls.RESET = ""


from version import WORKBENCH_VERSION, BACKEND_VERSION, MCP_TOOLS  # noqa: E402


# ANSI Shadow lettering spelling QECTOR.
# The previous art read Q-E-U-T-R-O: the third glyph was a U, and the last two
# were transposed. Read it letter by letter before changing it.
_BANNER_ART = """
 ██████╗ ███████╗ ██████╗████████╗ ██████╗ ██████╗
██╔═══██╗██╔════╝██╔════╝╚══██╔══╝██╔═══██╗██╔══██╗
██║   ██║█████╗  ██║        ██║   ██║   ██║██████╔╝
██║▄▄ ██║██╔══╝  ██║        ██║   ██║   ██║██╔══██╗
╚██████╔╝███████╗╚██████╗   ██║   ╚██████╔╝██║  ██║
 ╚══▀▀═╝ ╚══════╝ ╚═════╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝"""


def banner() -> str:
    """Build the banner at call time.

    Deliberately a function, not a module constant: as an f-string evaluated at
    import the colour codes were baked in before ``--no-color`` could be parsed,
    so the flag left the banner full of escape sequences.
    """
    return (
        f"{C.CYAN}{C.BOLD}{_BANNER_ART}\n"
        f"{C.MAGENTA}      Quantum Error Correction Decoder Workbench "
        f"{C.DIM}v{WORKBENCH_VERSION} / backend v{BACKEND_VERSION}{C.RESET}\n"
    )

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

def _can_unicode() -> bool:
    try:
        "┌─✔".encode(sys.stdout.encoding or "utf-8")
        return True
    except Exception:
        return False

USE_UNICODE = _can_unicode()

SYM_OK = "✔ PASS" if USE_UNICODE else "[OK]"
SYM_FAIL = "✘ FAIL" if USE_UNICODE else "[FAIL]"
SYM_WARN = "▲ WARN" if USE_UNICODE else "[WARN]"

BOX_TL = "┌" if USE_UNICODE else "+"
BOX_TR = "┐" if USE_UNICODE else "+"
BOX_BL = "└" if USE_UNICODE else "+"
BOX_BR = "┘" if USE_UNICODE else "+"
BOX_H = "─" if USE_UNICODE else "-"
BOX_V = "│" if USE_UNICODE else "|"


def print_json(data: Any) -> None:
    """Output clean, formatted JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


#: Matches any ANSI SGR sequence, so printable width can be measured whatever
#: colours a caller embedded. Replacing each known colour by name missed any
#: sequence not in that list and mis-measured the line.
_ANSI_RE = re.compile(r"\033\[[0-9;]*m")


def visible_len(text: str) -> int:
    """Printable width of ``text``, ignoring ANSI colour sequences."""
    return len(_ANSI_RE.sub("", text))


def draw_box(title: str, lines: list[str], width: int = 68, color: str = C.CYAN) -> None:
    """Draw a titled box whose three edges are the same width.

    The top border used ``width - len(title) - 4`` fill characters, one short of
    what the body and bottom occupy, so the right-hand edge never lined up.
    Body and bottom are both ``width + 2`` glyphs wide; the top must match.
    """
    fill = max(0, width - visible_len(title) - 3)
    top = f"{BOX_TL}{BOX_H} {C.BOLD}{title}{C.RESET} " + BOX_H * fill + BOX_TR
    bot = BOX_BL + BOX_H * width + BOX_BR
    print(f"{color}{top}{C.RESET}")
    for line in lines:
        padding = " " * max(0, width - visible_len(line) - 2)
        print(f"{color}{BOX_V}{C.RESET} {line}{padding} {color}{BOX_V}{C.RESET}")
    print(f"{color}{bot}{C.RESET}")


def cmd_decode(args: argparse.Namespace) -> int:
    import backend as be

    try:
        code = be.build_code(args.family, args.distance)
        raw = be.run_single_decode(
            code, error_rate=args.error_rate, decoder_kind=args.decoder, seed=args.seed
        )
        dec_obj = raw.get("result") if isinstance(raw, dict) else raw
        res = dec_obj.to_dict() if hasattr(dec_obj, "to_dict") else (dec_obj if isinstance(dec_obj, dict) else {})
        res["family"] = args.family
        res["distance"] = args.distance
        res["decoder"] = args.decoder
        res["n_qubits"] = getattr(code, "n_qubits", None)
        res["n_checks"] = getattr(code, "n_checks", None)
        res["error_rate"] = args.error_rate
        syndrome = raw.get("syndrome") if isinstance(raw, dict) else None
        err = raw.get("error") if isinstance(raw, dict) else None
        res["error_weight"] = int(sum(err)) if err is not None else None
        res["syndrome_weight"] = int(sum(syndrome)) if syndrome is not None else None

        if args.json:
            print_json(res)
        else:
            if not args.no_banner:
                print(banner())
            valid_str = f"{C.GREEN}✔ VALID{C.RESET}" if res.get("syndrome_valid") else f"{C.RED}✘ INVALID{C.RESET}"
            lines = [
                f"{C.BOLD}Decoder:{C.RESET}           {res.get('decoder')}",
                f"{C.BOLD}Code Family:{C.RESET}       {res.get('family')} (d={res.get('distance')})",
                f"{C.BOLD}Qubits / Checks:{C.RESET}   {res.get('n_qubits')} qubits | {res.get('n_checks')} check operators",
                f"{C.BOLD}Error Rate (p):{C.RESET}    {res.get('error_rate')}",
                f"{C.BOLD}Error Weight:{C.RESET}      {res.get('error_weight')}",
                f"{C.BOLD}Syndrome Weight:{C.RESET}   {res.get('syndrome_weight')}",
                f"{C.BOLD}Correction Weight:{C.RESET} {res.get('hamming_weight')}",
                f"{C.BOLD}Syndrome Valid:{C.RESET}    {valid_str}",
            ]
            if res.get("logical_failure") is not None:
                fail_str = f"{C.RED}TRUE{C.RESET}" if res.get("logical_failure") else f"{C.GREEN}FALSE{C.RESET}"
                lines.append(f"{C.BOLD}Logical Failure:{C.RESET}   {fail_str}")
            draw_box(f"DECODE RESULT: {args.family.upper()}", lines, color=C.CYAN)
        return 0
    except Exception as e:
        print(f"{C.RED}Error during decode: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_benchmark(args: argparse.Namespace) -> int:
    import backend as be

    try:
        res = be.run_benchmark(
            code_family=args.family,
            distance=args.distance,
            decoder_name=args.decoder,
            n_samples=args.samples,
            error_rate=args.error_rate,
            seed=args.seed,
        )
        if args.json:
            print_json(res)
        else:
            if not args.no_banner:
                print(banner())
            throughput = res.get('throughput_decodes_per_s', 0)
            lines = [
                f"{C.BOLD}Code Family:{C.RESET}       {res.get('code_family')} (d={res.get('distance')})",
                f"{C.BOLD}Decoder Kind:{C.RESET}      {res.get('method')}",
                f"{C.BOLD}Sample Trials:{C.RESET}     {res.get('n_trials')}",
                f"{C.BOLD}Error Rate (p):{C.RESET}    {res.get('p')}",
                f"{C.BOLD}Throughput:{C.RESET}        {C.GREEN}{C.BOLD}{throughput:,.1f}{C.RESET} decodes/sec",
                f"{C.BOLD}Execution Time:{C.RESET}    {res.get('decode_seconds', 0):.4f} seconds",
                f"{C.BOLD}Backend Used:{C.RESET}      {res.get('backend')}",
            ]
            draw_box(f"BENCHMARK PERFORMANCE: {args.decoder.upper()}", lines, color=C.MAGENTA)
        return 0
    except Exception as e:
        print(f"{C.RED}Error during benchmark: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_probe(args: argparse.Namespace) -> int:
    import autodebug

    try:
        report = autodebug.probe_decoders_on_family(
            family=args.family, distance=args.distance, error_rate=args.error_rate, seed=args.seed
        )
        if args.json:
            print_json(report)
        else:
            if not args.no_banner:
                print(banner())
            lines = []
            for r in report.get("results", []):
                status_icon = f"{C.GREEN}✔ PASS{C.RESET}" if r.get("ok") else f"{C.RED}✘ FAIL{C.RESET}"
                valid_icon = f"{C.GREEN}valid{C.RESET}" if r.get("syndrome_valid") else f"{C.RED}invalid{C.RESET}"
                method = f"{C.BOLD}{r.get('method'):20s}{C.RESET}"
                lines.append(f"  [{status_icon}] {method} | Hc==s: {valid_icon:12s} | weight: {r.get('hamming_weight')}")
            draw_box(f"DECODER COMPATIBILITY PROBE: {args.family.upper()} (d={args.distance})", lines, color=C.BLUE)
        return 0
    except Exception as e:
        print(f"{C.RED}Error during probe: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_diagnostics(args: argparse.Namespace) -> int:
    import autodebug

    try:
        rep = autodebug.run_self_diagnostics().to_dict()
        if args.json:
            print_json(rep)
        else:
            if not args.no_banner:
                print(banner())
            overall = rep.get('overall_status', 'unknown').upper()
            status_color = C.GREEN if overall == "PASS" else (C.YELLOW if overall == "DEGRADED" else C.RED)
            lines = [
                f"{C.BOLD}Overall Status:{C.RESET}   {status_color}{C.BOLD}{overall}{C.RESET}",
                f"{C.BOLD}Host Platform:{C.RESET}    {rep.get('platform')}",
                f"{C.BOLD}Python Version:{C.RESET}   {rep.get('python')}",
                f"{C.BOLD}Workbench App:{C.RESET}    {rep.get('workbench_version')}",
                f"{C.BOLD}Decoder Backend:{C.RESET}  {rep.get('backend_version')}",
                "",
                f"{C.BOLD}Subsystem Diagnostics:{C.RESET}",
            ]
            checks_raw = rep.get("checks", [])
            checks_list = checks_raw.values() if isinstance(checks_raw, dict) else checks_raw
            for item in checks_list:
                name = item.get("name", "") if isinstance(item, dict) else str(item)
                st = (item.get("status", "unknown") if isinstance(item, dict) else "").upper()
                detail = (item.get("detail") or item.get("message", "")) if isinstance(item, dict) else ""
                c_st = f"{C.GREEN}✔ PASS{C.RESET}" if st == "PASS" else (f"{C.YELLOW}▲ WARN{C.RESET}" if st == "WARN" else f"{C.RED}✘ FAIL{C.RESET}")
                lines.append(f"  [{c_st}] {C.BOLD}{name:24s}{C.RESET}: {detail}")
            draw_box("SYSTEM DIAGNOSTICS & ACCELERATION REPORT", lines, color=C.GREEN)
        return 0
    except Exception as e:
        print(f"{C.RED}Error during diagnostics: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_hardware(args: argparse.Namespace) -> int:
    import hardware_routing as hw

    import os
    import textwrap

    try:
        # detect_hardware() returns a HardwareProfile dataclass, not a mapping.
        info = hw.detect_hardware()
        payload = {
            "cuda": info.cuda_rust,
            "gpu": info.gpu,
            "opencl": info.opencl,
            "opencl_device": info.opencl_device,
            "opencl_host_devices": info.opencl_host_devices,
            "opencl_host_platform": info.opencl_host_platform,
            "opencl_reason": info.opencl_reason,
            "cpu_count": os.cpu_count(),
        }
        if args.json:
            print_json(payload)
        else:
            if not args.no_banner:
                print(banner())
            cuda_st = f"{C.GREEN}Available{C.RESET}" if info.cuda_rust else f"{C.DIM}Unavailable{C.RESET}"
            opencl_st = f"{C.GREEN}Available{C.RESET}" if info.opencl else f"{C.DIM}Unavailable{C.RESET}"
            lines = [
                f"{C.BOLD}CUDA Acceleration:{C.RESET} {cuda_st}",
                f"{C.BOLD}GPU Hardware:{C.RESET}      {info.gpu or 'N/A'}",
                f"{C.BOLD}OpenCL Engine:{C.RESET}     {opencl_st}",
                f"{C.BOLD}OpenCL Device:{C.RESET}     {info.opencl_device or 'N/A'}",
                f"{C.BOLD}Host OpenCL:{C.RESET}       {info.opencl_host_devices} device(s)"
                f"{f' via {info.opencl_host_platform}' if info.opencl_host_platform else ''}",
                f"{C.BOLD}CPU Threads:{C.RESET}       {os.cpu_count()} cores",
            ]
            # Say *why* OpenCL is off, so an unavailable backend never reads as a bug.
            if not info.opencl and info.opencl_reason:
                lines.append("")
                lines.append(f"{C.BOLD}Why OpenCL is unavailable:{C.RESET}")
                for chunk in textwrap.wrap(info.opencl_reason, 62):
                    lines.append(f"  {C.DIM}{chunk}{C.RESET}")
            draw_box("HARDWARE ACCELERATION PROFILES", lines, color=C.CYAN)
        return 0
    except Exception as e:
        print(f"{C.RED}Error detecting hardware: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_list_codes(args: argparse.Namespace) -> int:
    import backend as be

    try:
        codes = be.list_available_codes()
        if args.json:
            print_json(codes)
        else:
            if not args.no_banner:
                print(banner())
            lines = []
            for fam in codes.get("wired_families", []):
                info = be.get_code_family_info(fam)
                key = f"{C.CYAN}{C.BOLD}{fam:20s}{C.RESET}"
                lines.append(f"  - {key} : {info.get('label', fam)}")
            draw_box(f"SUPPORTED QUANTUM CODE FAMILIES ({len(codes.get('wired_families', []))})", lines, color=C.BLUE)
        return 0
    except Exception as e:
        print(f"{C.RED}Error listing codes: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_list_decoders(args: argparse.Namespace) -> int:
    import backend as be

    try:
        decs = [be.get_decoder_info(k) for k in be.DECODER_KINDS]
        if args.json:
            print_json({"decoders": decs, "count": len(decs)})
        else:
            if not args.no_banner:
                print(banner())
            lines = []
            for d in decs:
                name = f"{C.MAGENTA}{C.BOLD}{d.get('name'):22s}{C.RESET}"
                lines.append(f"  - {name} : {d.get('description')}")
            draw_box(f"SUPPORTED QUANTUM DECODERS ({len(decs)})", lines, color=C.MAGENTA)
        return 0
    except Exception as e:
        print(f"{C.RED}Error listing decoders: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_docgen(args: argparse.Namespace) -> int:
    import backend as be
    import doc_generator as dg

    try:
        code = be.build_code(args.family, args.param)
        gen = dg.ProfessionalDocGenerator()
        formats = args.formats.split(",") if args.formats else ["md", "html", "pdf", "json"]
        paths_map = gen.generate_all(code, formats=formats)
        res = {
            "family": args.family,
            "param": args.param,
            "formats": {fmt: str(p) for fmt, (ok, p) in paths_map.items() if ok},
            "failed_formats": [fmt for fmt, (ok, _) in paths_map.items() if not ok],
        }
        if args.json:
            print_json(res)
        else:
            if not args.no_banner:
                print(banner())
            lines = [f"{C.BOLD}Generated Formats for {args.family} (d={args.param}):{C.RESET}"]
            for fmt, path in res.get("formats", {}).items():
                lines.append(f"  [{C.GREEN}{fmt.upper():8s}{C.RESET}] {path}")
            if res.get("failed_formats"):
                lines.append(f"  [{C.RED}FAILED  {C.RESET}] {', '.join(res['failed_formats'])}")
            draw_box("DOCUMENT GENERATION COMPLETE", lines, color=C.GREEN)
        return 0
    except Exception as e:
        print(f"{C.RED}Error generating documentation: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_version(args: argparse.Namespace) -> int:
    import version_service as vs

    try:
        report = vs.get_version_report()
        if args.json:
            print_json(report)
        else:
            if not args.no_banner:
                print(banner())
            app_info = report.get("app", {})
            be_info = report.get("backend", {})
            app_ver = app_info.get("local", "N/A")
            be_ver = be_info.get("installed") or be_info.get("local", "N/A")
            any_update = bool(app_info.get("update_available") or be_info.get("update_available"))
            lines = [
                f"{C.BOLD}Workbench App:{C.RESET}    {app_ver} (PyPI: {app_info.get('latest', 'offline/N/A')})",
                f"{C.BOLD}Decoder Backend:{C.RESET}  {be_ver} (PyPI: {be_info.get('latest', 'offline/N/A')})",
                f"{C.BOLD}MCP Toolset:{C.RESET}      {MCP_TOOLS} tools (protocol 2024-11-05)",
                f"{C.BOLD}Update Status:{C.RESET}    " + (f"{C.YELLOW}Update Available{C.RESET}" if any_update else f"{C.GREEN}Up to date{C.RESET}"),
            ]
            draw_box("QECTOR SYSTEM VERSION STATUS", lines, color=C.CYAN)
        return 0
    except Exception as e:
        print(f"{C.RED}Error querying version: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_update(args: argparse.Namespace) -> int:
    import decoder_provisioner

    try:
        if not args.no_banner and not args.json:
            print(banner())
        res = decoder_provisioner.ensure(allow_upgrade=True)
        if args.json:
            print_json(res)
        else:
            status = f"{C.GREEN}✔ SUCCESS{C.RESET}" if res.get("ok") else f"{C.RED}✘ FAILED{C.RESET}"
            lines = [
                f"{C.BOLD}Update Action:{C.RESET}    {res.get('action')}",
                f"{C.BOLD}Status:{C.RESET}           {status}",
                f"{C.BOLD}Version:{C.RESET}          {res.get('version') or 'N/A'}",
                f"{C.BOLD}Site Path:{C.RESET}        {res.get('path') or 'N/A'}",
                f"{C.BOLD}Message:{C.RESET}          {res.get('message')}",
            ]
            draw_box("LIVE DECODER UPDATE REPORT", lines, color=C.GREEN if res.get("ok") else C.RED)
        return 0 if res.get("ok") else 1
    except Exception as e:
        print(f"{C.RED}Error updating decoder: {e}{C.RESET}", file=sys.stderr)
        return 1


def cmd_selftest(args: argparse.Namespace) -> int:
    import decoder_provisioner

    try:
        report = decoder_provisioner.self_check()
        if args.json:
            print_json(report)
        else:
            if not args.no_banner:
                print(banner())
            ok = report.get("import_ok", False)
            status_str = f"{C.GREEN}✔ VERIFIED{C.RESET}" if ok else f"{C.RED}✘ UNVERIFIED{C.RESET}"
            lines = [
                f"{C.BOLD}Import Verification:{C.RESET} {status_str}",
                f"{C.BOLD}Active Version:{C.RESET}      {report.get('active_version') or 'N/A'}",
                f"{C.BOLD}Active Site:{C.RESET}         {report.get('active_site') or 'N/A'}",
                f"{C.BOLD}Baseline Version:{C.RESET}    {report.get('baseline_version') or 'N/A'}",
                f"{C.BOLD}ABI Tag:{C.RESET}             {report.get('abi_tag')}",
                f"{C.BOLD}Interpreter:{C.RESET}         {report.get('interpreter')}",
            ]
            draw_box("DECODER PROVISIONER SELF-TEST", lines, color=C.CYAN if ok else C.RED)
        return 0 if ok else 1
    except Exception as e:
        print(f"{C.RED}Error during self-test: {e}{C.RESET}", file=sys.stderr)
        return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qector",
        description="QECTOR Decoder Workbench, unified command line interface",
    )
    parser.add_argument("--json", action="store_true", help="Output raw results in JSON format")
    parser.add_argument("--no-color", action="store_true", help="Disable ANSI colors")
    parser.add_argument("--no-banner", action="store_true", help="Suppress ASCII header banner")

    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # decode
    p_decode = subparsers.add_parser("decode", help="Run a single quantum error correction decode")
    p_decode.add_argument("--family", "-f", default="rotated_surface", help="Code family (default: rotated_surface)")
    p_decode.add_argument("--distance", "-d", type=int, default=5, help="Code distance / parameter (default: 5)")
    p_decode.add_argument("--decoder", "-m", default="blossom", help="Decoder kind (default: blossom)")
    p_decode.add_argument("--error-rate", "-p", type=float, default=0.05, help="Physical error rate (default: 0.05)")
    p_decode.add_argument("--seed", "-s", type=int, default=42, help="Random seed (default: 42)")
    p_decode.set_defaults(func=cmd_decode)

    # benchmark
    p_bench = subparsers.add_parser("benchmark", help="Run throughput benchmark for a decoder")
    p_bench.add_argument("--family", "-f", default="repetition", help="Code family (default: repetition)")
    p_bench.add_argument("--distance", "-d", type=int, default=5, help="Code distance (default: 5)")
    p_bench.add_argument("--decoder", "-m", default="blossom", help="Decoder kind (default: blossom)")
    p_bench.add_argument("--samples", "-n", type=int, default=40, help="Number of benchmark trials (default: 40)")
    p_bench.add_argument("--error-rate", "-p", type=float, default=0.05, help="Physical error rate (default: 0.05)")
    p_bench.add_argument("--seed", "-s", type=int, default=42, help="Random seed (default: 42)")
    p_bench.set_defaults(func=cmd_benchmark)

    # probe
    p_probe = subparsers.add_parser("probe", help="Probe all decoders on a code family")
    p_probe.add_argument("--family", "-f", default="rotated_surface", help="Code family (default: rotated_surface)")
    p_probe.add_argument("--distance", "-d", type=int, default=3, help="Code distance (default: 3)")
    p_probe.add_argument("--error-rate", "-p", type=float, default=0.05, help="Physical error rate (default: 0.05)")
    p_probe.add_argument("--seed", "-s", type=int, default=42, help="Random seed (default: 42)")
    p_probe.set_defaults(func=cmd_probe)

    # diagnostics
    p_diag = subparsers.add_parser("diagnostics", help="Run system self-diagnostics report")
    p_diag.set_defaults(func=cmd_diagnostics)

    # hardware
    p_hw = subparsers.add_parser("hardware", help="Show hardware detection and acceleration info")
    p_hw.set_defaults(func=cmd_hardware)

    # list-codes
    p_lc = subparsers.add_parser("list-codes", help="List all supported quantum code families")
    p_lc.set_defaults(func=cmd_list_codes)

    # list-decoders
    p_ld = subparsers.add_parser("list-decoders", help="List all supported decoders")
    p_ld.set_defaults(func=cmd_list_decoders)

    # docgen
    p_doc = subparsers.add_parser("docgen", help="Generate code family documentation")
    p_doc.add_argument("--family", "-f", default="rotated_surface", help="Code family (default: rotated_surface)")
    p_doc.add_argument("--param", "-p", type=int, default=5, help="Distance or size parameter (default: 5)")
    p_doc.add_argument("--formats", default="md,html,pdf,json", help="Comma-separated formats (md,html,pdf,json,latex,svg)")
    p_doc.set_defaults(func=cmd_docgen)

    # version
    p_ver = subparsers.add_parser("version", help="Print version details and update status")
    p_ver.set_defaults(func=cmd_version)

    # update
    p_upd = subparsers.add_parser("update", help="Check and update decoder live from PyPI")
    p_upd.set_defaults(func=cmd_update)

    # selftest
    p_st = subparsers.add_parser("selftest", help="Run decoder provisioner self-test probe")
    p_st.set_defaults(func=cmd_selftest)

    return parser


def main(args_list: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(args_list)
    if args.no_color:
        C.disable()
    if not hasattr(args, "func"):
        print(banner())
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
