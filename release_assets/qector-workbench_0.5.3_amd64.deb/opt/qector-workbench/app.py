"""app.py — Main application entry point for QECTOR Decoder Workbench.

Builds the full application window: a CTkTabview with the six feature tabs
plus a live Console tab, a status bar showing the app version and the
current code summary, per-tab crash isolation, a global Tk callback
exception hook with a non-modal error toast, a logging ``sys.excepthook``,
and an auto-update check that is scheduled only after the window exists.

Importing this module has zero side effects: no threads are started and no
network calls are made until a :class:`QectorApp` is constructed and its
event loop begins servicing timers.
"""

from __future__ import annotations

import sys
import tkinter
import traceback
from typing import Any, Optional

from version import FULL_VERSION, WORKBENCH_VERSION

try:
    import customtkinter as ctk
    _HAS_GUI = True
except Exception:
    _HAS_GUI = False


_WINDOW_WIDTH = 1280
_WINDOW_HEIGHT = 820
_MIN_WIDTH = 1100
_MIN_HEIGHT = 700

# (tab name, module, class) in display order; the Console tab is built inline.
_TAB_SPECS = [
    ("Code Explorer", "code_explorer_tab", "CodeExplorerTab"),
    ("Decoder Lab", "decoder_lab_tab", "DecoderLabTab"),
    ("Benchmark", "benchmark_tab", "BenchmarkTab"),
    ("Batch & Streaming", "batch_streaming_tab", "BatchStreamingTab"),
    ("Hardware", "hardware_tab", "HardwareTab"),
    ("Diagnostics", "diagnostics_tab", "DiagnosticsTab"),
    ("Documentation", "documentation_tab", "DocumentationTab"),
    ("Lab & Personal Info", "lab_info_tab", "LabInfoTab"),
]

TAB_NAMES = [spec[0] for spec in _TAB_SPECS] + ["Console"]


def _safe_logger():
    """Return the app logger, or None when logging cannot be initialised."""
    try:
        from logger import get_logger
        return get_logger()
    except Exception:
        return None


_EXCEPTHOOK_INSTALLED = False
_PREVIOUS_EXCEPTHOOK: Optional[Any] = None


def _install_sys_excepthook() -> None:
    """Install (once) a ``sys.excepthook`` that logs uncaught exceptions."""
    global _EXCEPTHOOK_INSTALLED, _PREVIOUS_EXCEPTHOOK
    if _EXCEPTHOOK_INSTALLED:
        return
    _PREVIOUS_EXCEPTHOOK = sys.excepthook

    def _hook(exc_type, exc_value, exc_tb):
        try:
            logger = _safe_logger()
            if logger is not None:
                logger.error(
                    "Uncaught exception:\n"
                    + "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
                )
        except Exception:
            pass
        try:
            if _PREVIOUS_EXCEPTHOOK is not None:
                _PREVIOUS_EXCEPTHOOK(exc_type, exc_value, exc_tb)
        except Exception:
            pass

    sys.excepthook = _hook
    _EXCEPTHOOK_INSTALLED = True


# ---------------------------------------------------------------------------
# Application class
# ---------------------------------------------------------------------------

class QectorApp:
    """Main QECTOR Decoder Workbench application with all tabs wired."""

    def __init__(self):
        if not _HAS_GUI:
            raise RuntimeError("customtkinter is required for QectorApp")

        import theme
        import threading_utils
        from console import Console
        from state import AppState

        self._logger = _safe_logger()
        self._colors = theme.COLORS
        self._fonts = theme.get_fonts()

        ctk.set_appearance_mode("dark")  # default color theme is kept as-is

        self._app = ctk.CTk()
        self.root = self._app  # backward-compatible alias
        self._width = _WINDOW_WIDTH
        self._height = _WINDOW_HEIGHT
        # The app re-versions itself to the live decoder backend: the topbar
        # never shows a hardcoded workbench number.  Seed from the installed
        # decoder version (synchronous, no network); the boot update check then
        # swaps in the live PyPI-resolved version.
        self._version_title = self._boot_version_string()
        self._app.title(self._version_title)
        self._app.geometry(f"{self._width}x{self._height}")
        self._app.minsize(_MIN_WIDTH, _MIN_HEIGHT)
        self._set_window_icon()

        self.state = AppState()
        self.console = Console()
        self.tabs: dict[str, Any] = {}
        self._toast: Any = None
        self._toast_after_id: Optional[str] = None
        self._update_after_id: Optional[str] = None
        self._destroyed = False

        # UI pump: safe marshalling of console/status updates coming from
        # worker threads onto the Tk main thread.
        self._ui = threading_utils.UiPump(self._app)

        # Global crash handling: Tk callbacks and uncaught thread exceptions
        # are logged and surfaced without ever killing the app.
        self._app.report_callback_exception = self._on_tk_exception
        _install_sys_excepthook()

        self._build_ui()
        self._center_and_lift_window()
        self.console.log(f"{self._version_title} ready", "INFO")

        # Auto-update check: scheduled AFTER construction; importing this
        # module starts zero threads and makes zero network calls.
        try:
            self._update_after_id = self._app.after(1500, self._start_update_check)
        except Exception:
            self._update_after_id = None

    # ── public surface used by tests ──────────────────────────────────
    def title(self) -> str:
        return self._app.title()

    def winfo_reqwidth(self) -> int:
        """The configured window width (matches the geometry set in __init__)."""
        return int(self._width)

    def winfo_reqheight(self) -> int:
        """The configured window height (matches the geometry set in __init__)."""
        return int(self._height)

    def destroy(self) -> None:
        self._destroyed = True
        try:
            self.console.unsubscribe(self._on_console_output)
        except Exception:
            pass
        # Close UI pumps first so no stale "after" timers outlive the window.
        try:
            self._ui.close()
        except Exception:
            pass
        for tab in list(self.tabs.values()):
            pump = getattr(tab, "_ui", None)
            if pump is not None:
                try:
                    pump.close()
                except Exception:
                    pass
        for after_id in (self._update_after_id, self._toast_after_id):
            if after_id is not None:
                try:
                    self._app.after_cancel(after_id)
                except Exception:
                    pass
        self._update_after_id = None
        self._toast_after_id = None
        # Cancel every remaining Tk "after" timer — including CustomTkinter's
        # internal DPI/scaling-tracker loop, which reschedules itself and would
        # otherwise fire against the destroyed interpreter (an intermittent
        # _tkinter.TclError when roots are created and torn down repeatedly).
        try:
            pending = self._app.tk.splitlist(self._app.tk.call("after", "info"))
            for aid in pending:
                try:
                    self._app.after_cancel(aid)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            self._app.update_idletasks()
        except Exception:
            pass
        try:
            self._app.destroy()
        except Exception:
            pass

    def mainloop(self) -> None:
        self._app.mainloop()

    # ── window icon (taskbar / title bar) ────────────────────────────
    def _set_window_icon(self) -> None:
        """Set the window icon, using the right mechanism per platform.

        Windows Tk supports ``.ico`` via ``iconbitmap``; Linux/X11 Tk does not
        (it expects an XBM there) and instead takes a raster image through
        ``iconphoto``.  On Linux we therefore load the bundled ``icon.png``
        (generated at build time from ``icon.jpg``) as a :class:`tkinter.PhotoImage`
        and keep a reference on ``self`` so Tk does not garbage-collect it,
        which would blank the icon.  The whole method is defensive: a missing
        or unreadable icon never prevents the window from opening.
        """
        try:
            import os
            # In a frozen onedir build ``icon.ico`` sits alongside the launcher,
            # while imported modules normally live under ``_internal``.  Probe
            # both locations so the Windows title bar/taskbar always receives
            # the shipped ICO rather than Tk's default feather icon.
            search_dirs: list[str] = []
            meipass = getattr(sys, "_MEIPASS", None)
            if meipass:
                search_dirs.append(meipass)
            try:
                search_dirs.append(os.path.dirname(os.path.abspath(sys.executable)))
            except Exception:
                pass
            search_dirs.append(os.path.dirname(os.path.abspath(__file__)))
            try:
                search_dirs.append(os.getcwd())
            except Exception:
                pass
            if os.name == "nt":
                # Give the app its own taskbar identity so Windows shows the
                # app icon instead of the generic pythonw/Tk feather icon.
                try:
                    import ctypes
                    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                        "iD01t.QECTOR.Workbench")
                except Exception:
                    pass
                for directory in search_dirs:
                    ico = os.path.join(directory, "icon.ico")
                    if os.path.isfile(ico):
                        self._reassert_icon_path = ico
                        try:
                            self._app.iconbitmap(ico)
                        except Exception:
                            pass
                        # CustomTkinter re-applies its OWN default icon ~200ms
                        # after window creation (the "generic" icon); re-assert
                        # the real icon a few times afterwards so it always wins,
                        # in both source runs and frozen builds.
                        for delay in (250, 500, 1200):
                            try:
                                self._app.after(delay, self._reassert_window_icon)
                            except Exception:
                                pass
                        break
                return
            # Linux / macOS: prefer a PNG via iconphoto.
            for directory in search_dirs:
                png = os.path.join(directory, "icon.png")
                if os.path.isfile(png):
                    self._icon_image = tkinter.PhotoImage(file=png)
                    self._app.iconphoto(True, self._icon_image)
                    break
        except Exception:
            pass

    def _reassert_window_icon(self) -> None:
        """Re-apply the real window icon after CustomTkinter's delayed reset."""
        if getattr(self, "_destroyed", False):
            return
        ico = getattr(self, "_reassert_icon_path", None)
        if not ico:
            return
        try:
            self._app.iconbitmap(ico)
            self._app.wm_iconbitmap(ico)
        except Exception:
            pass

    def _center_and_lift_window(self) -> None:
        """Center window on screen, deiconify, lift, and force focus."""
        try:
            self._app.update_idletasks()
            sw = self._app.winfo_screenwidth()
            sh = self._app.winfo_screenheight()
            if sw > 0 and sh > 0:
                x = max(0, (sw - self._width) // 2)
                y = max(0, (sh - self._height) // 2)
                self._app.geometry(f"{self._width}x{self._height}+{x}+{y}")
            self._app.deiconify()
            self._app.lift()
            self._app.focus_force()
            self._app.attributes("-topmost", True)
            self._app.after(600, lambda: self._app.attributes("-topmost", False))
        except Exception:
            pass

    # ── UI construction ───────────────────────────────────────────────
    def _build_ui(self) -> None:
        """Build the full application layout: tabview + status bar."""
        self._app.grid_columnconfigure(0, weight=1)
        self._app.grid_rowconfigure(0, weight=1)
        self._app.grid_rowconfigure(1, weight=0)

        menu = tkinter.Menu(self._app)
        menu.configure(bg='#2b2b2b', fg='#dcdcdc', activebackground='#4a9eff', activeforeground='#ffffff')
        
        doc_menu = tkinter.Menu(menu, tearoff=0)
        doc_menu.configure(bg='#2b2b2b', fg='#dcdcdc', activebackground='#4a9eff', activeforeground='#ffffff')
        
        doc_menu.add_command(label="Generate Documentation...", accelerator="Ctrl+D", 
                             command=lambda: self.tabs.get("Documentation")._on_generate() if "Documentation" in self.tabs else None)
        doc_menu.add_command(label="Open Export Folder", 
                             command=lambda: self.tabs.get("Documentation")._on_open_folder() if "Documentation" in self.tabs else None)
        doc_menu.add_separator()
        doc_menu.add_command(label="Export Official Docs...", 
                             command=lambda: self.tabs.get("Documentation")._on_export_official() if "Documentation" in self.tabs else None)
        
        menu.add_cascade(label="Documentation", menu=doc_menu)
        self._app.config(menu=menu)
        self._app.bind("<Control-d>", lambda e: self.tabs.get("Documentation")._on_generate() if "Documentation" in self.tabs else None)

        self.tabview = ctk.CTkTabview(self._app)
        self.tabview.grid(row=0, column=0, sticky="nsew", padx=6, pady=(6, 0))
        for name in TAB_NAMES:
            self.tabview.add(name)

        for tab_name, module_name, class_name in _TAB_SPECS:
            self._wire_tab(tab_name, module_name, class_name)

        self._build_console_tab()
        self._build_status_bar()
        self.tabview.set("Code Explorer")

    def _wire_tab(self, tab_name: str, module_name: str, class_name: str) -> None:
        """Import and instantiate a tab class into its tabview slot.

        Crash isolation: if the import or construction fails, a fallback
        frame showing the error is mounted instead and the rest of the app
        keeps working.
        """
        parent = self.tabview.tab(tab_name)
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(0, weight=1)
        try:
            import importlib
            mod = importlib.import_module(module_name)
            cls = getattr(mod, class_name)
            widget = cls(parent, state=self.state, console=self.console, fonts=self._fonts)
            widget.grid(row=0, column=0, sticky="nsew")
            self.tabs[tab_name] = widget
            self.console.log(f"Tab loaded: {tab_name}", "INFO")
        except Exception as exc:
            detail = traceback.format_exc()
            if self._logger is not None:
                self._logger.error(f"Failed to load tab {tab_name}:\n{detail}")
            self.console.log(f"Failed to load tab {tab_name}: {exc}", "ERROR")
            try:
                fallback = ctk.CTkFrame(parent, fg_color=self._colors["bg_panel"])
                fallback.grid(row=0, column=0, sticky="nsew")
                ctk.CTkLabel(
                    fallback,
                    text=f"Failed to load {tab_name}:\n\n{exc}",
                    text_color=self._colors["error"],
                    font=ctk.CTkFont(family=self._fonts.mono, size=11),
                    wraplength=760,
                    justify="left",
                ).pack(anchor="nw", padx=20, pady=20)
            except Exception:
                pass

    # ── Console tab ───────────────────────────────────────────────────
    def _build_console_tab(self) -> None:
        """Build the live Console tab: a read-only textbox fed by Console."""
        parent = self.tabview.tab("Console")
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_rowconfigure(1, weight=0)

        self._console_text = ctk.CTkTextbox(
            parent, wrap="word",
            font=ctk.CTkFont(family=self._fonts.mono, size=self._fonts.mono_size + 1),
        )
        self._console_text.grid(row=0, column=0, sticky="nsew", padx=8, pady=(8, 0))
        self._console_text.configure(state="disabled")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.grid(row=1, column=0, sticky="ew", padx=8, pady=6)
        ctk.CTkButton(
            btn_frame, text="Clear", width=90,
            command=self._clear_console,
            font=ctk.CTkFont(size=11),
        ).pack(side="right", padx=4)

        # Live subscription: Console.write may fire from worker threads, so
        # each chunk is marshalled to the UI thread before touching Tk.
        self.console.subscribe(self._on_console_output)
        self._refresh_console()

    def _on_console_output(self, text: str) -> None:
        """Console subscriber — may run on any thread; marshal to UI."""
        if self._destroyed:
            return
        self._ui.post(self._append_console, text)

    def _append_console(self, text: str) -> None:
        try:
            self._console_text.configure(state="normal")
            self._console_text.insert("end", text)
            self._console_text.see("end")
            self._console_text.configure(state="disabled")
        except tkinter.TclError:
            pass

    def _refresh_console(self) -> None:
        try:
            self._console_text.configure(state="normal")
            self._console_text.delete("1.0", "end")
            self._console_text.insert("1.0", self.console.get_text())
            self._console_text.see("end")
            self._console_text.configure(state="disabled")
        except tkinter.TclError:
            pass

    def _clear_console(self) -> None:
        self.console.clear()
        self._refresh_console()

    # ── Status bar ────────────────────────────────────────────────────
    def _build_status_bar(self) -> None:
        bar = ctk.CTkFrame(
            self._app, height=30, corner_radius=0,
            fg_color=self._colors["bg_status"],
        )
        bar.grid(row=1, column=0, sticky="ew")
        bar.grid_columnconfigure(0, weight=1)
        bar.grid_columnconfigure(1, weight=0)

        self._status_left = ctk.CTkLabel(
            bar, text=self._version_title, anchor="w",
            font=ctk.CTkFont(family=self._fonts.mono, size=10),
            text_color=self._colors["text_secondary"],
        )
        self._status_left.grid(row=0, column=0, sticky="w", padx=(10, 4), pady=2)

        self._status_right = ctk.CTkLabel(
            bar, text="no code built", anchor="e",
            font=ctk.CTkFont(family=self._fonts.mono, size=10),
            text_color=self._colors["text_secondary"],
        )
        self._status_right.grid(row=0, column=1, sticky="e", padx=(4, 10), pady=2)

        self.state.on_code_changed(self._on_state_code_changed)

    def _on_state_code_changed(self) -> None:
        """State listener — may fire from any thread; marshal to UI."""
        if self._destroyed:
            return
        self._ui.post(self._refresh_status_code)

    def _refresh_status_code(self) -> None:
        try:
            code = self.state.current_code
            if code is None:
                text = "no code built"
            else:
                n_qubits = getattr(code, "n_qubits", "?")
                text = (
                    f"{self.state.current_family_key} d={self.state.current_param}"
                    f" - {n_qubits} qubits"
                )
            self._status_right.configure(text=text)
        except tkinter.TclError:
            pass

    # ── Error toast + exception hooks ─────────────────────────────────
    def _show_error_toast(self, message: str) -> None:
        """Show a non-modal, self-dismissing error toast (bottom-right)."""
        try:
            self._dismiss_toast()
            msg = (message or "").strip() or "Unknown error"
            if len(msg) > 400:
                msg = msg[:400] + "…"
            toast = ctk.CTkFrame(
                self._app, corner_radius=8, border_width=1,
                fg_color=self._colors["bg_toast"],
                border_color=self._colors["border_toast"],
            )
            ctk.CTkLabel(
                toast, text=msg, wraplength=460, justify="left",
                text_color=self._colors["text_primary"],
                font=ctk.CTkFont(size=11),
            ).pack(padx=14, pady=(10, 6))
            ctk.CTkButton(
                toast, text="Dismiss", width=76, height=24,
                command=self._dismiss_toast,
                font=ctk.CTkFont(size=11),
            ).pack(padx=14, pady=(0, 10), anchor="e")
            toast.place(relx=1.0, rely=1.0, x=-18, y=-44, anchor="se")
            self._toast = toast
            self._toast_after_id = self._app.after(8000, self._dismiss_toast)
        except Exception:
            pass

    def _dismiss_toast(self) -> None:
        toast, self._toast = self._toast, None
        after_id, self._toast_after_id = self._toast_after_id, None
        if after_id is not None:
            try:
                self._app.after_cancel(after_id)
            except Exception:
                pass
        if toast is not None:
            try:
                toast.destroy()
            except Exception:
                pass

    def _on_tk_exception(self, exc_type, exc_value, exc_tb) -> None:
        """Global Tk callback exception hook — log, surface, never re-raise."""
        try:
            detail = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        except Exception:
            detail = f"{exc_type}: {exc_value}"
        try:
            if self._logger is not None:
                self._logger.error(f"Unhandled Tk callback exception:\n{detail}")
        except Exception:
            pass
        try:
            self.console.log(f"Unhandled exception:\n{detail}", "ERROR")
        except Exception:
            pass
        try:
            self._show_error_toast(f"{getattr(exc_type, '__name__', exc_type)}: {exc_value}")
        except Exception:
            pass

    def _boot_version_string(self) -> str:
        """The app's own version at construction — tracks the installed decoder
        backend (read live from the wheel), never a hardcoded workbench number.
        The moment a newer decoder (e.g. 0.6.7) is installed, the app identifies
        as that version."""
        ver = None
        try:
            import version_service
            ver = version_service.effective_app_version()
        except Exception:
            ver = None
        return f"QECTOR Decoder Workbench v{ver}" if ver else "QECTOR Decoder Workbench"

    def _apply_live_version(self, banner: str, title: str) -> None:
        """Update the status-bar version label and window title.
        Runs on the Tk main thread (posted via the UI pump); guarded so a late
        update after teardown is a no-op."""
        if self._destroyed:
            return
        try:
            status_left = getattr(self, "_status_left", None)
            if status_left is not None:
                status_left.configure(text=banner)
        except Exception:
            pass
        try:
            self._app.title(title)
        except Exception:
            pass

    # ── Version banner (deferred; console/log output only) ────────────
    def _start_update_check(self) -> None:
        self._update_after_id = None
        if self._destroyed:
            return
        try:
            import threading_utils
            threading_utils.run_in_background(self._update_check_worker)
        except Exception as exc:
            self.console.log(f"Version check could not start: {exc}", "WARN")

    def _update_check_worker(self) -> None:
        """Runs on a daemon thread; displays installed version banner only.

        No PyPI check, no auto-upgrade.  The app always shows the locally
        installed decoder version.
        """
        try:
            import version_service
            banner = version_service.format_version_banner()
        except Exception as exc:
            if self._logger is not None:
                self._logger.warning(f"Version banner failed: {exc}")
            return
        try:
            self.console.log(banner, "INFO")
            if self._logger is not None:
                self._logger.info(banner)
            installed = version_service.installed_backend_version() or "0.7.0"
            title = f"QECTOR Decoder Workbench v{installed}"
            try:
                self._ui.post(self._apply_live_version, banner, title)
            except Exception:
                pass
            self.console.log(
                "qector-decoder-v3 is up to date — using bundled local wheel", "INFO")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(on_ready=None) -> None:
    """Application entry point with a readable fatal-error fallback.

    *on_ready* is invoked once the main window is built and mapped; ``main.py``
    passes the boot-splash closer so the splash hands over to a visible window
    with no blank gap in between.
    """
    logger = _safe_logger()
    if not _HAS_GUI:
        msg = "ERROR: customtkinter is required to run QECTOR Workbench"
        print(msg, file=sys.stderr)
        if logger is not None:
            logger.error(msg)
        sys.exit(1)

    exit_code = 0
    try:
        if logger is not None:
            logger.info(f"Starting {FULL_VERSION}")
        app = QectorApp()
        if on_ready is not None:
            try:
                on_ready()
            except Exception:
                pass
        app.mainloop()
    except Exception:
        detail = traceback.format_exc()
        msg = (
            f"{FULL_VERSION} hit a fatal error and must close.\n"
            f"{detail}\n"
            "The full log is in the per-user data directory (logs/qector.log)."
        )
        print(msg, file=sys.stderr)
        if logger is not None:
            logger.error(msg)
        exit_code = 1
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
