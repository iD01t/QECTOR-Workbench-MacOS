"""version.py — Central version information for QECTOR Decoder Workbench."""

# Product version of the Workbench application itself. This is the public
# release line (0.5.x) and is deliberately INDEPENDENT of BACKEND_VERSION
# below: the decoder ships on its own cadence, and copying its number here has
# already caused a release to be labelled with the backend's version.
WORKBENCH_VERSION = "0.5.3"
DOC_GENERATOR_VERSION = "0.5.3"
# Backend: qector-decoder-v3.  It is NOT bundled into the app: decoder_provisioner
# downloads and activates it live from PyPI into an ABI-scoped managed site on
# first launch.  BACKEND_VERSION is the baseline this release was validated
# against; 0.6.2 is the minimum supported release.
BACKEND_VERSION = "0.7.0"
MIN_BACKEND_VERSION = "0.7.0"
MCP_TOOLS = 56
# Upstream backend attribution (see the QECTOR Decoder v3 user manual).
AUTHOR = "Guillaume Lessard / iD01t Productions"
AUTHOR_ORCID = "0009-0000-3465-3753"
PROJECT_URL = "https://www.qector.store"
FULL_VERSION = f"QECTOR Decoder Workbench v{WORKBENCH_VERSION}"

# ---------------------------------------------------------------------------
# Developer / business information, surfaced in-app (Documentation tab) and CLI.
# ---------------------------------------------------------------------------
COMPANY = "iD01t Productions"
MAINTAINER = "Guillaume Lessard"
CONTACT_EMAIL = "admin@qector.store"
PRICING_URL = "https://qector.store/pricing"
SUPPORT_URL = "https://www.qector.store"
LICENCE_SUMMARY = (
    "Source-available. Free for academic, personal and non-commercial research. "
    "Commercial use requires a paid licence."
)
LICENCE_EVALUATION = "60-day commercial evaluation available, creditable against a licence."


def business_info() -> dict:
    """Developer/business facts as a plain mapping (used by the GUI and CLI)."""
    return {
        "product": f"QECTOR Decoder Workbench v{WORKBENCH_VERSION}",
        "backend": f"qector-decoder-v3 v{BACKEND_VERSION} (Rust/PyO3 core, live from PyPI)",
        "company": COMPANY,
        "maintainer": MAINTAINER,
        "orcid": AUTHOR_ORCID,
        "contact": CONTACT_EMAIL,
        "website": PROJECT_URL,
        "pricing": PRICING_URL,
        "licence": LICENCE_SUMMARY,
        "evaluation": LICENCE_EVALUATION,
    }
