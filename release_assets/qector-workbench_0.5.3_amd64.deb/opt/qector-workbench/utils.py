"""utils.py — Shared utility functions for QECTOR Workbench."""

from __future__ import annotations

import hashlib
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def get_data_dir() -> Path:
    """Return the per-user writable data directory for the workbench.

    Resolution order: the QECTOR_DATA_DIR environment variable when set, else
    %LOCALAPPDATA%/QectorWorkbench on Windows, ~/Library/Application Support/
    QectorWorkbench on macOS, else the freedesktop location on Linux
    ($XDG_DATA_HOME/QectorWorkbench, falling back to
    ~/.local/share/QectorWorkbench, then legacy ~/.qector_workbench).  The
    directory is created on demand; any candidate that cannot be created is
    skipped and the fallback chain ends at the current working directory.
    Never raises.
    """
    import sys

    candidates: list[Path] = []
    try:
        override = os.environ.get("QECTOR_DATA_DIR", "").strip()
        if override:
            candidates.append(Path(override))
    except Exception:
        pass
    try:
        if os.name == "nt":
            local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
            if local_appdata:
                candidates.append(Path(local_appdata) / "QectorWorkbench")
            else:
                candidates.append(Path.home() / "AppData" / "Local" / "QectorWorkbench")
        elif sys.platform == "darwin":
            # macOS convention for per-user application data.
            candidates.append(Path.home() / "Library" / "Application Support" / "QectorWorkbench")
            candidates.append(Path.home() / ".qector_workbench")
        else:
            # Freedesktop XDG Base Directory spec, with a legacy fallback so
            # existing installs keep their data.
            xdg_data_home = os.environ.get("XDG_DATA_HOME", "").strip()
            if xdg_data_home:
                candidates.append(Path(xdg_data_home) / "QectorWorkbench")
            else:
                candidates.append(Path.home() / ".local" / "share" / "QectorWorkbench")
            candidates.append(Path.home() / ".qector_workbench")
    except Exception:
        pass
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            if candidate.is_dir():
                return candidate
        except Exception:
            continue
    try:
        return Path.cwd()
    except Exception:
        return Path(".")


def get_export_dir() -> Path:
    """Return the per-user export directory (get_data_dir()/"exports").

    Created on demand; if creation fails the (existing) data directory itself
    is returned.  Never raises.
    """
    data_dir = get_data_dir()
    export_dir = data_dir / "exports"
    try:
        export_dir.mkdir(parents=True, exist_ok=True)
        return export_dir
    except Exception:
        return data_dir


def validate_int(val: str, min_val: int = 0, max_val: int = 100) -> tuple[bool, str]:
    """Validate that a string represents an integer in [min_val, max_val]."""
    try:
        n = int(val)
        if n < min_val or n > max_val:
            return False, f"value {n} out of range [{min_val}, {max_val}]"
        return True, ""
    except (ValueError, TypeError):
        return False, f"invalid integer: {val!r}"


def format_number(num: float, precision: int = 2) -> str:
    """Format a number to a given precision."""
    return f"{num:.{precision}f}"


def safe_write_file(path: Any, content: str) -> tuple[bool, str]:
    """Atomically write content to a file, creating parent directories."""
    p = Path(path)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(content, encoding="utf-8")
        tmp.replace(p)
        return True, ""
    except Exception as e:
        return False, str(e)


def sha256_of(path: Any) -> str:
    """Return the real SHA-256 hex digest of a file, read in 1 MiB chunks."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_sidecar(path: Any) -> tuple[bool, str]:
    """Write ``<name>.sha256`` next to an exported file; return (ok, digest).

    The sidecar uses the coreutils layout (``<digest>  <name>``) so a lab can
    verify the artifact with ``sha256sum -c`` on Linux, or by eye against
    ``certutil -hashfile <name> SHA256`` on Windows.  Never raises: on failure
    the second element carries the reason, not a digest.
    """
    try:
        p = Path(path)
        digest = sha256_of(p)
        p.with_name(p.name + ".sha256").write_text(f"{digest}  {p.name}\n", encoding="utf-8")
        return True, digest
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"


def write_sha256_manifest(directory: Any, files: Iterable[Any],
                          manifest_name: str = "SHA256SUMS.txt") -> tuple[bool, str]:
    """Write a coreutils-format SHA-256 manifest for one export run.

    ``files`` is the artifact list of that run; only files that exist are
    listed.  Returns ``(True, manifest path)`` or ``(False, reason)``.
    Never raises.
    """
    try:
        directory = Path(directory)
        lines = [
            "# SHA-256 checksums -- QECTOR Decoder Workbench export",
            f"# Generated: {datetime.now(timezone.utc).isoformat(timespec='seconds')}",
            f"# Verify:    sha256sum -c {manifest_name}",
        ]
        for f in files:
            p = Path(f)
            if p.is_file():
                lines.append(f"{sha256_of(p)}  {p.name}")
        manifest = directory / manifest_name
        manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True, str(manifest)
    except Exception as exc:
        return False, f"{type(exc).__name__}: {exc}"
