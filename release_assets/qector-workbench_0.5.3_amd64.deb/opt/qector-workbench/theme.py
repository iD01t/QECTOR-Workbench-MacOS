"""theme.py — Theme, palette and font definitions for QECTOR Workbench."""

from __future__ import annotations

import sys
from types import SimpleNamespace

# matplotlib is intentionally NOT imported at module top-level so that
# ``import theme`` stays cheap and headless-safe.  configure_matplotlib()
# lazy-imports it and is safe to call multiple times.

COLORS = {
    "bg_panel": "#2b2b2b",
    "bg_panel_alt": "#333333",
    "bg_widget": "#3a3a3a",
    "text_primary": "#dcdcdc",
    "text_secondary": "#a0a0a0",
    "accent": "#4a9eff",
    "accent_dim": "#3a7bd5",
    # Status bar / toast / severity palette
    "bg_status": "#1f1f1f",
    "bg_toast": "#3a2a2a",
    "border_toast": "#ff5555",
    "error": "#ff5555",
    "warning": "#e5a53a",
    "success": "#4caf7d",
    "text_muted": "#8a8a8a",
    # Matplotlib dark-figure palette
    "fig_bg": "#242424",
    "axes_bg": "#2b2b2b",
    "grid": "#404040",
    "qubit_node": "#4a9eff",
    "check_node": "#ff9f43",
    "edge": "#6a6a6a",
    "bar": "#4a9eff",
    "bar_dim": "#3a5f8f",
    "bar_hot": "#ff9f43",
    "marker_p50": "#4caf7d",
    "marker_p99": "#ff9f43",
}

Fonts = SimpleNamespace


def get_fonts() -> SimpleNamespace:
    """Return a namespace with platform-appropriate font definitions.

    Consolas / Segoe UI are Windows fonts; on Linux (and as a macOS fallback)
    Tk would silently substitute an unstyled default.  The DejaVu family ships
    on virtually every Linux distribution and is bundled into the AppImage, so
    the workbench renders identically whether run from source or frozen.  The
    returned namespace shape is identical across platforms, so the six tab
    modules that read ``fonts.mono`` / ``fonts.ui`` need no changes.
    """
    if sys.platform.startswith("win"):
        mono, ui = "Consolas", "Segoe UI"
    elif sys.platform == "darwin":
        mono, ui = "Menlo", "Helvetica Neue"
    else:  # Linux / other POSIX
        mono, ui = "DejaVu Sans Mono", "DejaVu Sans"
    return SimpleNamespace(
        mono=mono,
        ui=ui,
        heading=ui,
        mono_size=10,
        ui_size=10,
        heading_size=14,
    )


# ---------------------------------------------------------------------------
# Matplotlib global quality configuration
# ---------------------------------------------------------------------------

def configure_matplotlib() -> None:
    """Set global matplotlib rcParams for maximum rendering quality.

    Safe to call multiple times and in headless / Agg mode.  Lazy-imports
    matplotlib so that importing theme itself stays cheap.
    """
    try:
        import matplotlib
        rc = matplotlib.rcParams

        # --- Resolution / layout -----------------------------------------
        rc["figure.dpi"] = 140          # crisp on-screen (HiDPI-friendly)
        rc["savefig.dpi"] = 300         # publication-grade exports
        rc["figure.constrained_layout.use"] = True

        # --- Anti-aliasing -----------------------------------------------
        rc["lines.antialiased"] = True
        rc["patch.antialiased"] = True
        rc["text.antialiased"] = True

        # --- Path rendering ----------------------------------------------
        rc["path.simplify"] = True
        rc["path.simplify_threshold"] = 0.1   # low threshold → high accuracy
        rc["agg.path.chunksize"] = 10000

        # --- Line / marker quality ----------------------------------------
        rc["lines.linewidth"] = 1.8
        rc["lines.markersize"] = 6
        rc["lines.solid_capstyle"] = "round"

        # --- Typography ---------------------------------------------------
        rc["font.size"] = 10
        rc["font.family"] = "sans-serif"
        # Prefer DejaVu (ships on all platforms), fall back gracefully
        rc["font.sans-serif"] = [
            "DejaVu Sans", "Segoe UI", "Helvetica Neue", "Arial", "sans-serif"
        ]
        rc["axes.titlesize"] = 11
        rc["axes.labelsize"] = 10

        # --- Axes / ticks ------------------------------------------------
        rc["axes.linewidth"] = 0.8
        rc["xtick.major.size"] = 4
        rc["xtick.minor.size"] = 2
        rc["xtick.major.width"] = 0.8
        rc["ytick.major.size"] = 4
        rc["ytick.minor.size"] = 2
        rc["ytick.major.width"] = 0.8

        # --- Background colours (dark theme) -----------------------------
        rc["figure.facecolor"] = COLORS["fig_bg"]
        rc["axes.facecolor"] = COLORS["axes_bg"]
        rc["savefig.facecolor"] = COLORS["fig_bg"]

        # --- Export quality ----------------------------------------------
        rc["svg.fonttype"] = "none"      # crisp SVG text (editable in Inkscape)
        rc["pdf.fonttype"] = 42          # TrueType embedding
        rc["ps.fonttype"] = 42

    except Exception:
        # matplotlib not installed or rcParams key changed — silently ignore
        pass


# ---------------------------------------------------------------------------
# Matplotlib dark styling helpers (figures are only ever touched on the Tk
# main thread; these helpers contain no matplotlib imports of their own so
# importing theme stays cheap).
# ---------------------------------------------------------------------------

def style_dark_figure(fig) -> None:
    """Apply the workbench dark palette to a matplotlib Figure."""
    try:
        fig.set_facecolor(COLORS["fig_bg"])
        # constrained_layout (set globally by configure_matplotlib) manages
        # padding automatically; only fall back to subplots_adjust when it is
        # not active so we don't trigger the "incompatible" UserWarning.
        try:
            if not fig.get_constrained_layout():
                fig.subplots_adjust(left=0.12, right=0.97, top=0.93, bottom=0.11)
        except AttributeError:
            fig.subplots_adjust(left=0.12, right=0.97, top=0.93, bottom=0.11)
    except Exception:
        pass


def style_dark_axes(
    ax,
    title: str = "",
    xlabel: str = "",
    ylabel: str = "",
    grid: bool = True,
) -> None:
    """Apply the workbench dark palette to a matplotlib Axes.

    Sets facecolor, spine/tick colors, optional title and axis labels, and a
    crisp antialiased grid drawn below the data.  Signature is unchanged from
    v1 so all call-sites continue to work as-is.
    """
    ax.set_facecolor(COLORS["axes_bg"])

    # Sharper, slightly lighter spines for contrast against the dark bg
    for spine in ax.spines.values():
        spine.set_color(COLORS["grid"])
        spine.set_linewidth(0.8)

    ax.tick_params(
        colors=COLORS["text_secondary"],
        labelsize=9,
        length=4,
        width=0.8,
    )
    # Tick labels inherit the same colour as the tick marks
    for label in ax.get_xticklabels() + ax.get_yticklabels():
        label.set_color(COLORS["text_secondary"])

    if title:
        ax.set_title(title, color=COLORS["text_primary"], fontsize=11, pad=6)
    if xlabel:
        ax.set_xlabel(xlabel, color=COLORS["text_secondary"], fontsize=10)
    if ylabel:
        ax.set_ylabel(ylabel, color=COLORS["text_secondary"], fontsize=10)

    if grid:
        ax.grid(
            True,
            color=COLORS["grid"],
            alpha=0.55,
            linewidth=0.6,
            antialiased=True,
        )
        ax.set_axisbelow(True)
    else:
        ax.grid(False)
        ax.set_axisbelow(True)


def style_dark_legend(legend) -> None:
    """Style a matplotlib legend to match the dark palette."""
    if legend is None:
        return
    try:
        frame = legend.get_frame()
        frame.set_facecolor(COLORS["bg_panel"])
        frame.set_edgecolor(COLORS["grid"])
        frame.set_linewidth(0.8)
        for text in legend.get_texts():
            text.set_color(COLORS["text_primary"])
    except Exception:
        pass
